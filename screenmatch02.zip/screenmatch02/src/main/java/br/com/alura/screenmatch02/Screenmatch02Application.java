package br.com.alura.screenmatch02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Screenmatch02Application {

	public static void main(String[] args) {
		SpringApplication.run(Screenmatch02Application.class, args);
	}

}
